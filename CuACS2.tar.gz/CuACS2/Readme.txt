If you are here that means you were able to extract the files.

In the terminal navigate to the CuACS2 file
Then run make
Then run ./CuACS2

The staff id is 1000
and the staff password is "password"
