/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.9.5
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QLabel *label;
    QStackedWidget *stackedWidget;
    QWidget *mainLoginPage;
    QPushButton *staffLoginButton;
    QPushButton *clientLoginButton;
    QWidget *staffLoginPage;
    QLabel *staffLoginLabel;
    QLabel *staffIdLabel;
    QLabel *staffPasswordLabel;
    QLineEdit *staffIdInput;
    QLineEdit *staffPasswordInput;
    QPushButton *staffLoginButton_2;
    QLabel *badLoginLabel;
    QWidget *staffPortalMainPage;
    QLabel *sPortalMainLabel;
    QPushButton *sPortalAddAnimal;
    QPushButton *sPortalViewAnimals;
    QWidget *viewAnimalsPage;
    QPushButton *backToStaffPortal;
    QTableWidget *SummaryTable;
    QWidget *addAnimalPage;
    QLineEdit *addAnimalType;
    QLineEdit *addAnimalBreed;
    QLineEdit *addAnimalAge;
    QLineEdit *addAnimalWeight;
    QLineEdit *addAnimalSize;
    QLineEdit *addAnimalColour;
    QLabel *addAnimalTypeLabel;
    QLabel *addAnimalBreedLabel;
    QLabel *addAnimalAgeLabel;
    QLabel *addAnimalSizeLabel;
    QLabel *addAnimalColourLabel;
    QLabel *addAnimalWeightLabel;
    QPushButton *addAnimalButton;
    QPushButton *addAnimalBackButton;
    QLabel *typeNotInputed;
    QLabel *breedNotInputed;
    QLabel *ageNotInputed;
    QLabel *sizeNotInputed;
    QLabel *weightNotInputed;
    QLabel *colourNotInputed;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(791, 533);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        label = new QLabel(centralWidget);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(20, 10, 351, 121));
        QFont font;
        font.setPointSize(60);
        font.setBold(false);
        font.setWeight(50);
        label->setFont(font);
        stackedWidget = new QStackedWidget(centralWidget);
        stackedWidget->setObjectName(QStringLiteral("stackedWidget"));
        stackedWidget->setGeometry(QRect(10, 150, 771, 341));
        mainLoginPage = new QWidget();
        mainLoginPage->setObjectName(QStringLiteral("mainLoginPage"));
        staffLoginButton = new QPushButton(mainLoginPage);
        staffLoginButton->setObjectName(QStringLiteral("staffLoginButton"));
        staffLoginButton->setGeometry(QRect(150, 100, 171, 71));
        QFont font1;
        font1.setPointSize(15);
        staffLoginButton->setFont(font1);
        clientLoginButton = new QPushButton(mainLoginPage);
        clientLoginButton->setObjectName(QStringLiteral("clientLoginButton"));
        clientLoginButton->setEnabled(false);
        clientLoginButton->setGeometry(QRect(430, 100, 171, 71));
        clientLoginButton->setFont(font1);
        stackedWidget->addWidget(mainLoginPage);
        staffLoginPage = new QWidget();
        staffLoginPage->setObjectName(QStringLiteral("staffLoginPage"));
        staffLoginLabel = new QLabel(staffLoginPage);
        staffLoginLabel->setObjectName(QStringLiteral("staffLoginLabel"));
        staffLoginLabel->setGeometry(QRect(310, 20, 151, 41));
        QFont font2;
        font2.setPointSize(20);
        staffLoginLabel->setFont(font2);
        staffIdLabel = new QLabel(staffLoginPage);
        staffIdLabel->setObjectName(QStringLiteral("staffIdLabel"));
        staffIdLabel->setGeometry(QRect(160, 116, 81, 21));
        staffIdLabel->setFont(font1);
        staffPasswordLabel = new QLabel(staffLoginPage);
        staffPasswordLabel->setObjectName(QStringLiteral("staffPasswordLabel"));
        staffPasswordLabel->setGeometry(QRect(160, 150, 101, 21));
        staffPasswordLabel->setFont(font1);
        staffIdInput = new QLineEdit(staffLoginPage);
        staffIdInput->setObjectName(QStringLiteral("staffIdInput"));
        staffIdInput->setGeometry(QRect(280, 109, 271, 31));
        staffPasswordInput = new QLineEdit(staffLoginPage);
        staffPasswordInput->setObjectName(QStringLiteral("staffPasswordInput"));
        staffPasswordInput->setGeometry(QRect(280, 144, 271, 31));
        staffLoginButton_2 = new QPushButton(staffLoginPage);
        staffLoginButton_2->setObjectName(QStringLiteral("staffLoginButton_2"));
        staffLoginButton_2->setGeometry(QRect(469, 190, 83, 25));
        badLoginLabel = new QLabel(staffLoginPage);
        badLoginLabel->setObjectName(QStringLiteral("badLoginLabel"));
        badLoginLabel->setGeometry(QRect(280, 80, 241, 17));
        QFont font3;
        font3.setPointSize(8);
        badLoginLabel->setFont(font3);
        badLoginLabel->setStyleSheet(QStringLiteral("color: rgb(239, 41, 41);"));
        stackedWidget->addWidget(staffLoginPage);
        staffPortalMainPage = new QWidget();
        staffPortalMainPage->setObjectName(QStringLiteral("staffPortalMainPage"));
        sPortalMainLabel = new QLabel(staffPortalMainPage);
        sPortalMainLabel->setObjectName(QStringLiteral("sPortalMainLabel"));
        sPortalMainLabel->setGeometry(QRect(270, 10, 231, 71));
        QFont font4;
        font4.setPointSize(30);
        sPortalMainLabel->setFont(font4);
        sPortalAddAnimal = new QPushButton(staffPortalMainPage);
        sPortalAddAnimal->setObjectName(QStringLiteral("sPortalAddAnimal"));
        sPortalAddAnimal->setGeometry(QRect(160, 120, 191, 71));
        sPortalViewAnimals = new QPushButton(staffPortalMainPage);
        sPortalViewAnimals->setObjectName(QStringLiteral("sPortalViewAnimals"));
        sPortalViewAnimals->setGeometry(QRect(400, 120, 191, 71));
        stackedWidget->addWidget(staffPortalMainPage);
        viewAnimalsPage = new QWidget();
        viewAnimalsPage->setObjectName(QStringLiteral("viewAnimalsPage"));
        backToStaffPortal = new QPushButton(viewAnimalsPage);
        backToStaffPortal->setObjectName(QStringLiteral("backToStaffPortal"));
        backToStaffPortal->setGeometry(QRect(330, 310, 83, 25));
        SummaryTable = new QTableWidget(viewAnimalsPage);
        if (SummaryTable->columnCount() < 7)
            SummaryTable->setColumnCount(7);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        SummaryTable->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        SummaryTable->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        QTableWidgetItem *__qtablewidgetitem2 = new QTableWidgetItem();
        SummaryTable->setHorizontalHeaderItem(2, __qtablewidgetitem2);
        QTableWidgetItem *__qtablewidgetitem3 = new QTableWidgetItem();
        SummaryTable->setHorizontalHeaderItem(3, __qtablewidgetitem3);
        QTableWidgetItem *__qtablewidgetitem4 = new QTableWidgetItem();
        SummaryTable->setHorizontalHeaderItem(4, __qtablewidgetitem4);
        QTableWidgetItem *__qtablewidgetitem5 = new QTableWidgetItem();
        SummaryTable->setHorizontalHeaderItem(5, __qtablewidgetitem5);
        QTableWidgetItem *__qtablewidgetitem6 = new QTableWidgetItem();
        SummaryTable->setHorizontalHeaderItem(6, __qtablewidgetitem6);
        SummaryTable->setObjectName(QStringLiteral("SummaryTable"));
        SummaryTable->setGeometry(QRect(-5, 1, 791, 291));
        SummaryTable->setColumnCount(7);
        SummaryTable->horizontalHeader()->setDefaultSectionSize(109);
        SummaryTable->horizontalHeader()->setMinimumSectionSize(50);
        SummaryTable->verticalHeader()->setVisible(false);
        stackedWidget->addWidget(viewAnimalsPage);
        addAnimalPage = new QWidget();
        addAnimalPage->setObjectName(QStringLiteral("addAnimalPage"));
        addAnimalType = new QLineEdit(addAnimalPage);
        addAnimalType->setObjectName(QStringLiteral("addAnimalType"));
        addAnimalType->setGeometry(QRect(90, 90, 113, 25));
        addAnimalBreed = new QLineEdit(addAnimalPage);
        addAnimalBreed->setObjectName(QStringLiteral("addAnimalBreed"));
        addAnimalBreed->setGeometry(QRect(290, 90, 113, 25));
        addAnimalAge = new QLineEdit(addAnimalPage);
        addAnimalAge->setObjectName(QStringLiteral("addAnimalAge"));
        addAnimalAge->setGeometry(QRect(480, 90, 113, 25));
        addAnimalWeight = new QLineEdit(addAnimalPage);
        addAnimalWeight->setObjectName(QStringLiteral("addAnimalWeight"));
        addAnimalWeight->setGeometry(QRect(480, 170, 113, 25));
        addAnimalSize = new QLineEdit(addAnimalPage);
        addAnimalSize->setObjectName(QStringLiteral("addAnimalSize"));
        addAnimalSize->setGeometry(QRect(90, 170, 113, 25));
        addAnimalColour = new QLineEdit(addAnimalPage);
        addAnimalColour->setObjectName(QStringLiteral("addAnimalColour"));
        addAnimalColour->setGeometry(QRect(290, 170, 113, 25));
        addAnimalTypeLabel = new QLabel(addAnimalPage);
        addAnimalTypeLabel->setObjectName(QStringLiteral("addAnimalTypeLabel"));
        addAnimalTypeLabel->setGeometry(QRect(90, 70, 64, 17));
        addAnimalBreedLabel = new QLabel(addAnimalPage);
        addAnimalBreedLabel->setObjectName(QStringLiteral("addAnimalBreedLabel"));
        addAnimalBreedLabel->setGeometry(QRect(290, 70, 64, 17));
        addAnimalAgeLabel = new QLabel(addAnimalPage);
        addAnimalAgeLabel->setObjectName(QStringLiteral("addAnimalAgeLabel"));
        addAnimalAgeLabel->setGeometry(QRect(480, 70, 64, 17));
        addAnimalSizeLabel = new QLabel(addAnimalPage);
        addAnimalSizeLabel->setObjectName(QStringLiteral("addAnimalSizeLabel"));
        addAnimalSizeLabel->setGeometry(QRect(90, 150, 64, 17));
        addAnimalColourLabel = new QLabel(addAnimalPage);
        addAnimalColourLabel->setObjectName(QStringLiteral("addAnimalColourLabel"));
        addAnimalColourLabel->setGeometry(QRect(290, 150, 64, 17));
        addAnimalWeightLabel = new QLabel(addAnimalPage);
        addAnimalWeightLabel->setObjectName(QStringLiteral("addAnimalWeightLabel"));
        addAnimalWeightLabel->setGeometry(QRect(480, 150, 101, 17));
        addAnimalButton = new QPushButton(addAnimalPage);
        addAnimalButton->setObjectName(QStringLiteral("addAnimalButton"));
        addAnimalButton->setGeometry(QRect(420, 240, 171, 51));
        addAnimalBackButton = new QPushButton(addAnimalPage);
        addAnimalBackButton->setObjectName(QStringLiteral("addAnimalBackButton"));
        addAnimalBackButton->setGeometry(QRect(90, 300, 83, 25));
        typeNotInputed = new QLabel(addAnimalPage);
        typeNotInputed->setObjectName(QStringLiteral("typeNotInputed"));
        typeNotInputed->setGeometry(QRect(90, 120, 131, 17));
        typeNotInputed->setStyleSheet(QStringLiteral("color: rgb(239, 41, 41);"));
        breedNotInputed = new QLabel(addAnimalPage);
        breedNotInputed->setObjectName(QStringLiteral("breedNotInputed"));
        breedNotInputed->setGeometry(QRect(290, 120, 141, 17));
        breedNotInputed->setStyleSheet(QStringLiteral("color: rgb(239, 41, 41);"));
        ageNotInputed = new QLabel(addAnimalPage);
        ageNotInputed->setObjectName(QStringLiteral("ageNotInputed"));
        ageNotInputed->setGeometry(QRect(480, 120, 141, 16));
        ageNotInputed->setStyleSheet(QStringLiteral("color: rgb(239, 41, 41);"));
        sizeNotInputed = new QLabel(addAnimalPage);
        sizeNotInputed->setObjectName(QStringLiteral("sizeNotInputed"));
        sizeNotInputed->setGeometry(QRect(90, 200, 131, 17));
        sizeNotInputed->setStyleSheet(QStringLiteral("color: rgb(239, 41, 41);"));
        weightNotInputed = new QLabel(addAnimalPage);
        weightNotInputed->setObjectName(QStringLiteral("weightNotInputed"));
        weightNotInputed->setGeometry(QRect(480, 200, 141, 16));
        weightNotInputed->setStyleSheet(QStringLiteral("color: rgb(239, 41, 41);"));
        colourNotInputed = new QLabel(addAnimalPage);
        colourNotInputed->setObjectName(QStringLiteral("colourNotInputed"));
        colourNotInputed->setGeometry(QRect(290, 200, 141, 17));
        colourNotInputed->setStyleSheet(QStringLiteral("color: rgb(239, 41, 41);"));
        stackedWidget->addWidget(addAnimalPage);
        MainWindow->setCentralWidget(centralWidget);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        MainWindow->setStatusBar(statusBar);

        retranslateUi(MainWindow);

        stackedWidget->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", Q_NULLPTR));
        label->setText(QApplication::translate("MainWindow", "CuACS", Q_NULLPTR));
        staffLoginButton->setText(QApplication::translate("MainWindow", "Staff Login", Q_NULLPTR));
        clientLoginButton->setText(QApplication::translate("MainWindow", "Client Login", Q_NULLPTR));
        staffLoginLabel->setText(QApplication::translate("MainWindow", "Staff Login", Q_NULLPTR));
        staffIdLabel->setText(QApplication::translate("MainWindow", "Staff Id", Q_NULLPTR));
        staffPasswordLabel->setText(QApplication::translate("MainWindow", "Password", Q_NULLPTR));
        staffLoginButton_2->setText(QApplication::translate("MainWindow", "Login", Q_NULLPTR));
        badLoginLabel->setText(QApplication::translate("MainWindow", "Wrong Id or password.  Please try again.", Q_NULLPTR));
        sPortalMainLabel->setText(QApplication::translate("MainWindow", "Staff Portal", Q_NULLPTR));
        sPortalAddAnimal->setText(QApplication::translate("MainWindow", "Add Animal", Q_NULLPTR));
        sPortalViewAnimals->setText(QApplication::translate("MainWindow", "View Animals", Q_NULLPTR));
        backToStaffPortal->setText(QApplication::translate("MainWindow", "Back", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem = SummaryTable->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QApplication::translate("MainWindow", "Animal Id", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem1 = SummaryTable->horizontalHeaderItem(1);
        ___qtablewidgetitem1->setText(QApplication::translate("MainWindow", "Type", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem2 = SummaryTable->horizontalHeaderItem(2);
        ___qtablewidgetitem2->setText(QApplication::translate("MainWindow", "Breed", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem3 = SummaryTable->horizontalHeaderItem(3);
        ___qtablewidgetitem3->setText(QApplication::translate("MainWindow", "Age", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem4 = SummaryTable->horizontalHeaderItem(4);
        ___qtablewidgetitem4->setText(QApplication::translate("MainWindow", "Size", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem5 = SummaryTable->horizontalHeaderItem(5);
        ___qtablewidgetitem5->setText(QApplication::translate("MainWindow", "Colour", Q_NULLPTR));
        QTableWidgetItem *___qtablewidgetitem6 = SummaryTable->horizontalHeaderItem(6);
        ___qtablewidgetitem6->setText(QApplication::translate("MainWindow", "Weight", Q_NULLPTR));
        addAnimalTypeLabel->setText(QApplication::translate("MainWindow", "Type", Q_NULLPTR));
        addAnimalBreedLabel->setText(QApplication::translate("MainWindow", "Breed", Q_NULLPTR));
        addAnimalAgeLabel->setText(QApplication::translate("MainWindow", "Age", Q_NULLPTR));
        addAnimalSizeLabel->setText(QApplication::translate("MainWindow", "Size", Q_NULLPTR));
        addAnimalColourLabel->setText(QApplication::translate("MainWindow", "Colour", Q_NULLPTR));
        addAnimalWeightLabel->setText(QApplication::translate("MainWindow", "Weight (lbs)", Q_NULLPTR));
        addAnimalButton->setText(QApplication::translate("MainWindow", "Add Animal", Q_NULLPTR));
        addAnimalBackButton->setText(QApplication::translate("MainWindow", "Back", Q_NULLPTR));
        typeNotInputed->setText(QApplication::translate("MainWindow", "Please enter type.", Q_NULLPTR));
        breedNotInputed->setText(QApplication::translate("MainWindow", "Please enter breed.", Q_NULLPTR));
        ageNotInputed->setText(QApplication::translate("MainWindow", "Please enter age.", Q_NULLPTR));
        sizeNotInputed->setText(QApplication::translate("MainWindow", "Please enter size.", Q_NULLPTR));
        weightNotInputed->setText(QApplication::translate("MainWindow", "Please enter weight.", Q_NULLPTR));
        colourNotInputed->setText(QApplication::translate("MainWindow", "Please enter colour.", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
